#ifndef MAIN_H
#define MAIN_H

double constant(const char *name);

#endif /* MAIN_H */
